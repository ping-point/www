A Pen created at CodePen.io. You can find this one at http://codepen.io/karlovidek/pen/reemvP.

 GSAP + Slick slider slider with preview of previous/next slides